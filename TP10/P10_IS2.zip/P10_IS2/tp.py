import numpy as np


tasa_mensual = 0.01
inversion_mensual = -1000
valor_final = 18000

def calcular_vpn(meses_costo, mes_cobro):
    # El proceso mediante el cual los flujos en distintos momentos del tiempo 
    # se los transforma a sus equivalentes presentes (hoy) se llama "descuento"
    costos_presentes = sum(inversion_mensual / (1 + tasa_mensual)**i for i in range(1, meses_costo + 1))
    ingreso_presente = valor_final / (1 + tasa_mensual)**mes_cobro
    vpn = costos_presentes + ingreso_presente
    rentabilidad = vpn / abs(costos_presentes)
    return vpn, rentabilidad, costos_presentes

# a) VPN del proyecto según los planes (12 meses)
vpn_a, rent_a, costos_a = calcular_vpn(12, 12)
print(f"a) VPN normal: ${vpn_a:.2f}")

# b) VPN extendido por 3 meses (15 meses total)
vpn_b, rent_b, costos_b = calcular_vpn(15, 15)
print(f"b) VPN extendido 3 meses: ${vpn_b:.2f}")

# c) Rentabilidad en ambos escenarios
print(f"c) Rentabilidad Normal: {rent_a*100:.2f}% | Rentabilidad Extendido: {rent_b*100:.2f}%")

# f) Costo mensual máximo aceptable para extender a 15 meses manteniendo el VPN original
# Ecuación: vpn_a = sum(-C / (1.01)^i) + 18000 / (1.01)^15
factor_descuento_15m = sum(1 / (1 + tasa_mensual)**i for i in range(1, 16))
ingreso_presente_15m = valor_final / (1 + tasa_mensual)**15
costo_maximo_mensual = (ingreso_presente_15m - vpn_a) / factor_descuento_15m
print(f"f) Costo máximo mensual aceptable: ${costo_maximo_mensual:.2f}")