print ("hello world")
